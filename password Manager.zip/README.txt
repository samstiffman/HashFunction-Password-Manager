Thank you for downloading my password manager

If the passwordManager asks you to enter in the master key and you have not set one it could mean several things: 
	1. When entering the database to connect to you entered the wrong name
	2. Your database is corrupted re-download the sample template database, or reextract it 	
	   from the ZIP file
	
Important info:
	1. The SQLITE database used stores the passwords you want to store and the Master 	password as encrypted versions of the passwords, this is to prevent it from being 		accessed from outside of the program	

	2. The passwords can only be decrypted from within the JAVA program but to recover any 	passwords you can just copy the encrypted SQL data to a new SQLITE database where you 	
	paste them, make sure you set the master password in the SQLITE database to 0 if you 
	want to reset it

SETUP:

Change the batch file to be the destination of your .jar file for example this line is all that is necesary to run the program, save the file as a .bat and double click to run


java -jar D:\passwordManager.jar
